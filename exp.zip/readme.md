
## To run
```
make all
./client 127.0.0.1
./server
```
